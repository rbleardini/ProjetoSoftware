package visao;
public class Principal 
{
	public static void main(String[] args) 
	{
		FrameInvisivel frameInvisivel = new FrameInvisivel();
		frameInvisivel.setVisible(false);
	}
}
